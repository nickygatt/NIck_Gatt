id = input("Enter employee ID: ")
if(len(id)>5):
    exit()
if not id:
    exit()
try:
    id = int(id)
except:
    exit()
cant_use = ['! " @ # $ % ^ & * ( ) _ + / = ; : [ ] { } \\ )']
name = input("Enter employee name: ")
if not name:
    exit()
if(any(item in list(name) for item in cant_use)):
    exit()
    email = input("Enter email ID: ")
if not email:
    exit()
    cant_use = ['! " \' # $ % ^ & * = ( ) _ + , < > / ? ; : [ ] { } \\ )']
if(any(item in list(email) for item in cant_use)):
    exit()
    address = input("Enter Address:")
    cant_use = ['! " \' # $ % ^ & * _ = + , < > / ? ; : [ ] { } )']
if not address:
    address = ''
if(any(item in list(address) for item in cant_use)):
    exit()
    print(f"Hello, {name}. Your Employee ID is {id}, and your email address is {email}.")
if(len(address) == 0):
    print("You did not provide an address.")
else:
    print(f"Your address is {address}")