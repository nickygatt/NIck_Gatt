import re

total_employees = 0
employees = []

def getEmployeeId(): #function to read ID
    id = None
    id = input("Enter empolyee ID:")
    return id

def getEmployeeName(): #funcion to read name
    name = input("Enter Employee name:")
    if(len(name) == 0):
        return None
    else:
        return name

def getEmployeeEmail(): #funcion to read e-mail
    email = input("Enter Employee email:")
    if(len(email) == 0):
        return None
    else:
        return email

def getEmployeeAddress(): #funcion to read address
    
    address = input("Enter employee address:")
    if(len(address) == 0):
        return None
    else:
        return address

def inputEmpty(): #funcion to print empty
    print("Input is Empty!")

    while total_employees < 5:
        employee = {}
        ID = getEmployeeId()
    while(ID == None):
        inputEmpty()
        ID = getEmployeeId()
    while(len(ID)>5):
        print("Information invalid. Please Re-enter valid information")
        ID = getEmployeeId()

    employee["ID"] = int(ID)

    name = getEmployeeName()
    while(name == None):
        inputEmpty()
        name = getEmployeeName()

    while(checkIfSpecialCharacter(name) == True):
        name = getEmployeeName()

    employee["name"] = name

    email = getEmployeeEmail()
    while(email == None):
        inputEmpty()
        email = getEmployeeEmail()
    
    employee["e-mail"] = email

    address = getEmployeeAddress()
    while(address == None):
        inputEmpty
        address = getEmployeeAddress()

    while(checkIfSpecialCharacter(address) == True):
        address = getEmployeeAddress()

    employee["address"] = address

    print("Hello,{0}.Your Employee ID is {1}, and your email address is {2}".format(name,ID,email))
    print("Your address is {0}".format(address))
    print()

    employees.append(employee) #Adding employee dictionary to employees list
    total_employees = total_employees+1 #incrementing total_employee count

print("list of employee dictionaries:")
print(employees)