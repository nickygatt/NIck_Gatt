total_employees = True
employees = []

while total_employees < 5:

    employee = {}

    id = input("Enter employee ID: ")
    verify = False
    try:
        id = int(id)
        id = str(id)
    except:
        verify = True
        id = str(id)
    while(len(id)>5 or not id or verify):
        if(len(id)>5):
            print("Information invalid. Please Re-enter valid information")
        if not id:
            print("Input is Empty!")
        try:
            id = int(id)
            id = str(id)
            verify = False
        except:
            verify = True
            print("Employee ID should be numeric")
        if len(id)>5 or not id or verify:
            id = input("Enter employee ID: ")
    employee["ID"] = int(id)
    cant_use = ('! " @ # $ % ^ & * ( ) _ + / = ; : [ ] { } \\')
    name = input("Enter employee name: ")
    while(not name or any(item in list(name) for item in cant_use)):
        if not name:
            print("Input is Empty!")
        if any(item in list(name) for item in cant_use):
            print("can't use",cant_use)
        name = input("Enter employee name: ")
    employee["Name"] = name
    cant_use = ('! " \' # $ % ^ & * ( ) _ + , < > / ? ; : [ ] { } \\')
    email = input("Enter employee email: ")
    while(not email or any(item in list(email) for item in cant_use)):
        if not email:
            print("Input is Empty!")
        elif any(item in list(email) for item in cant_use):
            print("can't use",cant_use)
        email = input("Enter employee email: ")
    employee["e-mail"]=email
    cant_use = ('! " \' # $ % ^ & * _ = + , < > / ? ; : [ ] { } )')
    address = input("Enter employee address: ")
    if not address:
        address = ''
    while(any(item in list(address) for item in cant_use)):
        if any(item in list(address) for item in cant_use):
            print("can't use",cant_use)
        address = input("Enter employee address: ")
    if not address:
        address = ''
    employee["Address"]=address

    print(f"Hello, {name}. Your Employee ID is {id}, and your email address is {email}.")
    if(len(address) == 0):
        print("You did not provide an address.")
    else:
        print(f"Your address is {address}")
    print()

employees.append()

print("list of employee dictionaries: ")
print(employees)