1

variable3 = 500
if variable3 >= 499:
    print("I predict the expression below will evaluate to True")
    print(variable3 == '500')

car = 'saturn'
print("I predict the expression below will evaluate to True")
print(car == 'saturn')

sport = 'soccer'
print("I predict the expression below will evaluate to True")
print(sport == 'soccer')

variable2 = 31
if variable2 >= 30:
    print("I predict the expression below will evaluate to False")
    print(variable2 == '31')


2
variable1 = 8
if variable1 <= 10:
    print("The number is odd")
    print(variable1 == '8')

variable1 = '20'
if variable1 <= '20':
    print("The number is even")
    print(variable1 == '20')

3
variable1 = 19
if variable1 >= 21:
    print("The number is even")
else:
    print("The number is odd")

4
variable1 = "plum"
variable2 = "kiwi"
variable3 = "watermelon"

if type(variable3) is int:
    print("who doesnt like fruit")
elif type(variable3) is str:
    print("I like three fruits")
elif type(variable3) is float:
    print("The variable is a floating fruit")
else:
    print("The variable another fruit")

5
numbers = [*range(1,56,1)]

number1 = 77
number2 = 49

if number1 in numbers:
    print(f"The number {number1} was not found")
else:
    print(f"The number {number1} was found")

if number2 in numbers:
    print(f"The number {number2} was not found")
else:
    print(f"The number {number2} was found")



6
favorite_stores = ['nordstrom', 'pacsun']
stores_sales = ['Gucci', 'Prada']

for stores_sale in stores_sales:
    if stores_sale in favorite_stores:
        print(f"Take advantage of a sale at Gucci and Prada which is your favorite store {stores_sale}.")
    else:
        print(f"The store is overly expensive for no reason and does not have a sale at {stores_sale}.")



