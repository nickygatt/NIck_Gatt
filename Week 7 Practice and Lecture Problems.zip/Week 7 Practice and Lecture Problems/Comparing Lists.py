list1 = ["one", "two", "three"]
list2 = ["one", "apple", "three", "four"]

# list1 = [1, 2, 3]
# list2 = ["1", "2", "3"]

if len(list1) < len(list2):
    print("list 2 is bigger in terms of number of values than list 1")