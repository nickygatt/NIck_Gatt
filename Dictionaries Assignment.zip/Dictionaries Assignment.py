data = [1121, "Jackie Grainger", 22.22,
        1122, "Jignesh Thrakkar", 25.25,
        1127, "Dion Green", 28.75,
        1132, "JacobGerber", 22.2,
        1133, "SarahSanderson", 23.45,
        1137, "BrandoHeck", 23.3,
        1138, "Rochelle", 25.84,
        1152, "David Toma", 22.65,
        1157, "Charles King", 25.5,
        1158, "Jackie Grainger", 23.3]

companyraises = [10, 20, 30, 40, 50, 45, 55, 65, 75, 15]

# the data I need to store
list_of_names = ['Jackie Grainger','Jignesh Thrakkar','Dion Green','JacobGerber', "SarahSanderson", "BrandoHeck", "Rochelle", "David Toma", "Charles King", "Jackie Grainger"]
list_of_wages = ['22.22', '25.25', '28.75', '22.2', '23.45', '23.3', '25.84', '22.65', '25.5', '23.3']
list_of_employee_information = ['1121', '1122', '1127', '1132', '1133', '1137', '1138', '1152', '1152', '1157', '1158']

# the list where we are going to store the data above
all_data = []

# variable that will help us retrieve values from one of the lists
count_index = 0

for temp_name in list_of_names:

	all_data.append({'name':temp_name, 'wages': list_of_wages, 'employee info':list_of_employee_information[count_index]})

	count_index = count_index + 1

print(all_data)
